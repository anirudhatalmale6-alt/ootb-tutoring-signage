# OOTB Tutoring — Brand Assets
**Direction C — "The Spark"**  ·  prepared 12 August 2026  ·  lockup revised 14 August 2026 (rev 2 - text outlined)

A box with the idea escaping it — the moment a concept finally clicks for a student.

---

## Colours

| Role | Hex | Use |
|---|---|---|
| OOTB Green | `#23A455` | Primary. The box, the tagline, buttons. |
| Spark Amber | `#FDC64D` | Accent only. The spark, highlights, small CTAs. |
| Deep Navy | `#0B3D57` | Headings and the "OOTB" wordmark. |
| Bright Green | `#38EF7D` | Reversed/dark backgrounds only. |

Amber is a genuine second brand colour — the site is currently all green, and this
gives you a warm accent for things you want noticed.

## Typeface
**Poppins** — ExtraBold (900) for "OOTB", ExtraBold (800) letterspaced for "TUTORING".
Free from Google Fonts. Already loaded by the website.

---

## Which file do I use?

| Situation | File |
|---|---|
| Website header, letterhead, invoices | `png/ootb-logo-primary-800w.png` or `svg/ootb-logo-primary.svg` |
| Anything on a dark background | `svg/ootb-logo-reversed.svg` |
| Printing in one colour / fax / stamp | `svg/ootb-logo-mono-navy.svg` |
| Etched, embroidered, or on a dark shirt | `svg/ootb-logo-mono-white.svg` |
| Browser tab icon | `favicon/favicon.ico` + `favicon/favicon-32.png` |
| Phone home screen / social profile | `favicon/apple-touch-icon-180.png` |
| Instagram / Facebook / WhatsApp avatar | `png/ootb-appicon-512.png` |
| Big print — banner, sign, vehicle | any `svg/` file (scales to any size, never blurs) |

**Always prefer the SVG** when whoever you're sending it to accepts it — a printer,
a sign maker, a shirt supplier. SVG stays razor sharp at any size. PNGs are for
websites, email signatures, and anywhere SVG isn't accepted.

---

## Revision — 14 August 2026

The lockup files were redrawn. Two things changed and nothing else:

1. **The canvas was cropped to the artwork.** The old files carried 34% empty
   margin inside the image, so at any given placement size the drawing came out
   a third smaller than the space it was given. Aspect ratio went 3.57:1 → 2.75:1.
2. **The tagline was enlarged** from 16 to 20pt and from Bold to ExtraBold, and
   is now centred under the wordmark rather than justified to it. "TUTORING" is
   a long word — holding it to the exact width of "OOTB" is what was keeping it
   small.

If you have the old files in a letterhead, invoice template or email signature,
replace them: the new ones are not drop-in the same shape.

**Rev 2, same day:** the lettering in the SVG files is now converted to outlines
rather than live text. This means the files no longer need the Poppins font to be
installed anywhere - send them to a printer, a sign maker or a shirt supplier and
the wordmark comes out right on their machine whether they own the font or not.
The website now uses the SVG for its header and footer logo, so the logo is drawn
from maths and stays perfectly sharp on any screen at any zoom.

## Rules

**Do**
- Keep clear space around the logo of at least the height of the "O" in OOTB.
- Use the reversed version on dark — never the dark version on a dark photo.
- Keep the green and amber as supplied.

**Don't**
- Stretch or squash it. Hold Shift when resizing.
- Re-colour it, add a gradient, a drop shadow, or an outline.
- Rebuild the wordmark in a different font.
- Place the colour version on a busy photo — use reversed or mono-white instead.

---

## Smallest usable sizes
- Full lockup: **110px wide** on screen, 23mm in print.
- Icon alone: **16px** (that's the favicon build, which is drawn slightly heavier so it survives).

---

## Files

```
svg/    ootb-logo-primary.svg        full lockup, colour
        ootb-logo-reversed.svg       full lockup for dark backgrounds
        ootb-logo-mono-navy.svg      single colour, navy
        ootb-logo-mono-white.svg     single colour, white
        ootb-icon-colour.svg         mark only
        ootb-icon-white.svg          mark only, white
        ootb-icon-mono-navy.svg      mark only, navy
        ootb-favicon-mark.svg        tightened mark, drawn heavier for tiny sizes
        ootb-appicon.svg             rounded green tile, white mark

png/    ootb-logo-primary-400/800/1600w.png     transparent background
        ootb-logo-reversed-400/800/1600w.png    transparent background
        ootb-logo-mono-navy-800w.png
        ootb-logo-mono-white-800w.png
        ootb-icon-colour-64/128/256/512.png
        ootb-icon-white-256.png
        ootb-icon-mono-navy-256.png
        ootb-appicon-512.png

favicon/ favicon.ico                 multi-size, for the browser tab
         favicon-16/32/48.png
         apple-touch-icon-180/192.png
```

All PNGs have transparent backgrounds except the app icon, which is deliberately solid green.
